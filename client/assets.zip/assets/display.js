const socket = io();
const ROOM = 'showroom_demo';

const $image = document.getElementById('displayImage');
const $overlay = document.getElementById('overlay');
const $projectLabel = document.getElementById('projectLabel');
const $spotTitle = document.getElementById('spotTitle');
const $spotSub = document.getElementById('spotSub');
const $flashRing = document.getElementById('flashRing');
const $statusDot = document.getElementById('statusDot');
const $waiting = document.getElementById('waitingScreen');
const $container = document.getElementById('displayContainer');

let firstLoad = true;

// --- Preload all images from all projects ---
function preloadImages() {
  PROJECTS.forEach(project => {
    project.spots.forEach(spot => {
      const img = new Image();
      img.src = spot.imgUrl;
    });
  });
}

// --- Socket events ---

socket.on('connect', () => {
  socket.emit('join', { role: 'display', room: ROOM });
  $statusDot.classList.add('connected');
});

socket.on('disconnect', () => {
  $statusDot.classList.remove('connected');
});

socket.on('spot:change', ({ imgUrl, title, sub, project }) => {
  if (firstLoad) {
    $waiting.classList.add('hidden');
    firstLoad = false;
  }

  $image.style.opacity = '0';

  setTimeout(() => {
    $image.src = imgUrl;
    $projectLabel.textContent = project;
    $spotTitle.textContent = title;
    $spotSub.textContent = sub;

    $image.onload = () => {
      $image.style.opacity = '1';
      $overlay.style.opacity = '1';
      triggerFlash();
    };

    if ($image.complete) {
      $image.style.opacity = '1';
      $overlay.style.opacity = '1';
      triggerFlash();
    }
  }, 200);
});

function triggerFlash() {
  $flashRing.classList.remove('animate');
  void $flashRing.offsetWidth;
  $flashRing.classList.add('animate');
}

// --- Auto fullscreen on first click ---
$container.addEventListener('click', () => {
  if (document.fullscreenElement) return;
  $container.requestFullscreen?.() ||
    $container.webkitRequestFullscreen?.() ||
    $container.msRequestFullscreen?.();
}, { once: true });

// --- Init ---
preloadImages();
