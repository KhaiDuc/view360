const PROJECTS = [
  {
    id: 'vinhomes',
    name: 'Vinhomes Ocean Park',
    spots: [
      { id: 0, title: 'Mặt tiền', sub: 'Toàn cảnh dự án', imgUrl: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=1920&q=90' },
      { id: 1, title: 'Phòng khách', sub: 'Nội thất 3PN mẫu', imgUrl: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1920&q=90' },
      { id: 2, title: 'Hồ bơi', sub: 'Tầng 5 · Tiện ích', imgUrl: 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=1920&q=90' },
      { id: 3, title: 'Ban đêm', sub: 'View ánh sáng đô thị', imgUrl: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1920&q=90' },
    ]
  },
  {
    id: 'masteri',
    name: 'Masteri Thảo Điền',
    spots: [
      { id: 0, title: 'Lobby', sub: 'Sảnh tiếp đón', imgUrl: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=1920&q=90' },
      { id: 1, title: 'Penthouse', sub: 'View sông Sài Gòn', imgUrl: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=1920&q=90' },
      { id: 2, title: 'Gym', sub: 'Tầng 3 · Tiện ích', imgUrl: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1920&q=90' },
    ]
  }
];
